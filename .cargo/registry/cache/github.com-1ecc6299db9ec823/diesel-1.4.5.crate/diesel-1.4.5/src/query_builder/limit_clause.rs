simple_clause!(NoLimitClause, LimitClause, " LIMIT ");
