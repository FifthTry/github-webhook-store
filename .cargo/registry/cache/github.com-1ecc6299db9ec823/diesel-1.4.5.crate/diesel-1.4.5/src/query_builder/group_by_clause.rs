simple_clause!(NoGroupByClause, GroupByClause, " GROUP BY ");
