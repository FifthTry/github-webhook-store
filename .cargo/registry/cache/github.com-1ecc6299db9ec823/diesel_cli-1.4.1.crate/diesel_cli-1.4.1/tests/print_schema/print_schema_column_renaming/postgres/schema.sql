CREATE TABLE with_keywords (
    fn INTEGER PRIMARY KEY,
    let INTEGER NOT NULL,
    extern INTEGER NOT NULL
);
