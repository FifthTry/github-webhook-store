CREATE SCHEMA custom_schema;
CREATE TABLE in_public (id SERIAL PRIMARY KEY);
CREATE TABLE custom_schema.in_schema (id SERIAL PRIMARY KEY);
